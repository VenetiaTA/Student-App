package com.example.student.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.student.R;
import com.example.student.model.Marksheet;

import java.util.ArrayList;

public class MarksheetAdapter extends RecyclerView.Adapter<MarksheetAdapter.MarksheetHolder>{

    private Context context;
    private ArrayList<Marksheet> marksheets;

    public MarksheetAdapter(Context context, ArrayList<Marksheet> marksheets) {
        this.context = context;
        this.marksheets = marksheets;
    }

    @Override
    public MarksheetHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.marsheet_layout,parent,false);
        return new MarksheetHolder(v);
    }

    @Override
    public void onBindViewHolder(MarksheetHolder holder, int position) {
        Marksheet marksheet=getMarkseet(position);
        if(marksheet!=null)
        {
            holder.mrollno.setText(marksheet.getMarkrollno());
            holder.msubject1.setText(marksheet.getMarksheet_subject1());
            holder.msubject2.setText(marksheet.getMarksheet_subject2());
            holder.msubject3.setText(marksheet.getMarksheet_subject3());
            holder.msubject4.setText(marksheet.getMarksheet_subject4());
            holder.msubject5.setText(marksheet.getMarksheet_subject5());
            holder.mcgpa.setText(marksheet.getMarksheet_cgpa());
            holder.mmark1.setText(marksheet.getMarksheet_mark1());
            holder.mmark2.setText(marksheet.getMarksheet_mark2());
            holder.mmark3.setText(marksheet.getMarksheet_mark3());
            holder.mmark4.setText(marksheet.getMarksheet_mark4());
            holder.mmark5.setText(marksheet.getMarksheet_mark5());
            holder.msem_num.setText(marksheet.getMarksheet_sem_num());
        }

    }

    @Override
    public int getItemCount() {
        return marksheets.size();
    }

    private  Marksheet getMarkseet(int position)
    {
        return marksheets.get(position);
    }

    class MarksheetHolder extends RecyclerView.ViewHolder{

        TextView msubject1,msubject2,msubject3,msubject4,msubject5,mmark1,mmark2,mmark3,mmark4,mmark5,mrollno,mcgpa,msem_num;

        public MarksheetHolder(@NonNull View itemView) {
            super(itemView);

            msubject1=itemView.findViewById(R.id.subject1);
            msubject2=itemView.findViewById(R.id.subject2);
            msubject3=itemView.findViewById(R.id.subject3);
            msubject4=itemView.findViewById(R.id.subject4);
            msubject5=itemView.findViewById(R.id.subject5);
            mmark1=itemView.findViewById(R.id.mark1);
            mmark2=itemView.findViewById(R.id.mark2);
            mmark3=itemView.findViewById(R.id.mark3);
            mmark4=itemView.findViewById(R.id.mark4);
            mmark5=itemView.findViewById(R.id.mark5);
            mrollno=itemView.findViewById(R.id.mark_rollno);
            mcgpa=itemView.findViewById(R.id.cgpa);
            msem_num=itemView.findViewById(R.id.semester_number);
        }
    }
}
