package com.example.student;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class register extends AppCompatActivity {
    TextView registered;
    EditText registered_rollno,registered_password,registered_confrmpassword;
    Button registerbutton;
    studentdatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db=new studentdatabase(this);
        registered_rollno= findViewById(R.id.registerrollnoedittext);
        registered_password= findViewById(R.id.registerpasswordedittext);
        registered_confrmpassword= findViewById(R.id.passwordcnfrmedititext);
        registerbutton= findViewById(R.id.registerbutton);
        registered= findViewById(R.id.registeredtext);


        registered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginintent=new Intent(register.this,MainActivity.class);
                startActivity(loginintent);
            }
        });

        registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String rollno=registered_rollno.getText().toString().trim();
                String pass=registered_password.getText().toString().trim();
                String confrmpass=registered_confrmpassword.getText().toString().trim();
                if(pass.equals(confrmpass))
                {
                    long val=db.addstudents(rollno,pass);
                    System.out.println(val);
                    if(val>0)
                    {
                        Toast.makeText(register.this,"Registered successfully",Toast.LENGTH_SHORT).show();
                        Intent moveloginintent=new Intent(register.this,MainActivity.class);
                        startActivity(moveloginintent);
                    }
                    else
                    {
                        Toast.makeText(register.this,"Registeration error",Toast.LENGTH_SHORT).show();
                    }
                }
                else
                {
                    Toast.makeText(register.this,"Mismatch between password and confirm password",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
