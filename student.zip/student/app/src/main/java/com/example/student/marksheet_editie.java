package com.example.student;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

import com.example.student.db.MarksheetDB;
import com.example.student.db.MarksheetDao;
import com.example.student.model.Marksheet;


public class marksheet_editie extends AppCompatActivity {

    private EditText mark_subject1,mark_subject2,mark_subject3,mark_subject4,mark_subject5,mark_mark1,mark_mark2,mark_mark3,mark_mark4,mark_mark5,mark_sem_number;
    private MarksheetDao marksheetDao;
    String marksheet_edite_rollno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marksheet_editie);

        mark_subject1=findViewById(R.id.mesubject1);
        mark_subject2=findViewById(R.id.mesubject2);
        mark_subject3=findViewById(R.id.mesubject3);
        mark_subject4=findViewById(R.id.mesubject4);
        mark_subject5=findViewById(R.id.mesubject5);
        mark_sem_number=findViewById(R.id.mesemester_number);
        mark_mark1=findViewById(R.id.memark1);
        mark_mark2=findViewById(R.id.memark2);
        mark_mark3=findViewById(R.id.memark3);
        mark_mark4=findViewById(R.id.memark4);
        mark_mark5=findViewById(R.id.memark5);
        marksheetDao= MarksheetDB.getInstance(this).marksheetDao();
        Bundle bundle=getIntent().getExtras();
        marksheet_edite_rollno=bundle.getString("rollno");
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.edit_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.save_note)
        {
            omSaveNote();
        }
        return super.onOptionsItemSelected(item);
    }

    private void omSaveNote() {
        String subject1,subject2,subject3,subject4,subject5,cgpa;
        String mark1,mark2,mark3,mark4,mark5,sem_number;
        double m1,m2,m3,m4,m5;
        cgpa="TOTAL: ";
        double temp;
        subject1=mark_subject1.getText().toString();
        subject2=mark_subject2.getText().toString();
        subject3=mark_subject3.getText().toString();
        subject4=mark_subject4.getText().toString();
        subject5=mark_subject5.getText().toString();
        mark1= mark_mark1.getText().toString();
        mark2= mark_mark2.getText().toString();
        mark3= mark_mark3.getText().toString();
        mark4= mark_mark4.getText().toString();
        mark5= mark_mark5.getText().toString();
        sem_number=mark_sem_number.getText().toString();
        m1=Double.parseDouble(mark1);
        m2=Double.parseDouble(mark2);
        m3=Double.parseDouble(mark3);
        m4=Double.parseDouble(mark4);
        m5=Double.parseDouble(mark5);
        temp=(m1+m2+m3+m4+m5);
        double  temp1=(temp/500)*10;
        cgpa=cgpa+temp+"  and GPA : "+temp1;
        if((!subject1.isEmpty()) && (!subject2.isEmpty()) && (!subject3.isEmpty()) && (!subject3.isEmpty()) &&
                (!subject4.isEmpty()) && (!subject5.isEmpty()) && (!mark1.isEmpty()) && (!mark2.isEmpty()) && (!mark3.isEmpty()) && (!mark4.isEmpty()) && (!mark5.isEmpty()) && (!sem_number.isEmpty()) )
        {
            Marksheet marksheet=new Marksheet(marksheet_edite_rollno,sem_number,subject1,subject2,subject3,subject4,subject5,mark1,mark2,mark3,mark4,mark5,cgpa);
            marksheetDao.insertMarksheet(marksheet);
            finish();
        }
    }
}
