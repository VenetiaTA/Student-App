package com.example.student;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



public class studentdatabase extends SQLiteOpenHelper {
    public static final String DATABASE_NAME ="register.db";
    public static final String TABLE_NAME = "studentusers";
    public static final String COL_1 ="ID";
    public static final String COL_2 ="student_rollno";
    public static final String COL_3 ="student_paassword";

    public studentdatabase(Context context) {
        super(context, DATABASE_NAME,null,1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE studentusers (ID INTEGER PRIMARY KEY AUTOINCREMENT,student_rollno TEXT,student_paassword TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
        onCreate(db);
    }
    public  long addstudents(String rollno,String password)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("student_rollno",rollno);
        contentValues.put("student_paassword",password);
        long result=db.insert("studentusers",null,contentValues);
        System.out.println("inside");
        db.close();
        return result;
    }
    public boolean checkstudent(String rollno,String password)
    {
        String[] columns={COL_1};
        SQLiteDatabase db= getReadableDatabase() ;
        String selection=COL_2 + "=?" + " and " + COL_3 + "=?";
        String[] selectionArgs={rollno,password};
        Cursor cursor=db.query(TABLE_NAME,columns,selection,selectionArgs,null,null,null);
        int count=cursor.getCount();
        cursor.close();
        db.close();
        return count > 0;
    }
}
