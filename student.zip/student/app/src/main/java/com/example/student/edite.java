package com.example.student;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

import com.example.student.db.NotesDB;
import com.example.student.db.NotesDao;
import com.example.student.model.Note;

import java.util.Date;

public class edite extends AppCompatActivity {
    private EditText inputNote;
    private NotesDao dao;
    String editactivity_rollno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edite);


        inputNote=findViewById(R.id.input_note);
        dao=NotesDB.getInstance(this).notesDao();
        Bundle bundle=getIntent().getExtras();
        editactivity_rollno=bundle.getString("rollno");  
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.edit_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.save_note)
        {
            omSaveNote();
        }
        return super.onOptionsItemSelected(item);
    }

    private void omSaveNote() {
        String text=inputNote.getText().toString();
        if(!text.isEmpty())
        {
            long date=new Date().getTime();
            Note note=new Note(editactivity_rollno,text,date);
            dao.insertNote(note);

            finish();
        }

    }
}
