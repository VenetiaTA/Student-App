package com.example.student;

import android.content.Intent;
import android.os.Bundle;

import com.example.student.adapters.NotesAdapter;
import com.example.student.db.NotesDB;
import com.example.student.db.NotesDao;
import com.example.student.model.Note;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class notesactivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ArrayList<Note> notes;
    private NotesAdapter adapter;
    private NotesDao dao;
    String notesactivity_rollno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notesactivity);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        recyclerView=findViewById(R.id.notes_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               onAddNewNote();
            }
        });
        dao= NotesDB.getInstance(this).notesDao();
        Bundle bundle=getIntent().getExtras();
        notesactivity_rollno=bundle.getString("rollno");
    }

    private void loadNotes() {
        this.notes=new ArrayList<>();
        List<Note> list =dao.getNotes(notesactivity_rollno);
        this.notes.addAll(list);
        this.adapter=new NotesAdapter(this,this.notes);
        this.recyclerView.setAdapter(adapter);
        //adapter.notifyDataSetChanged();
    }

    private void onAddNewNote() {

        Intent editintent=new Intent(this,edite.class);
        editintent.putExtra("rollno",notesactivity_rollno);
        startActivity(editintent);
        //startActivity(new Intent(this,edite.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes();
   }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.homepage_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.menu_homepage:
            {
                finish();
                break;
            }
        }
        return super.onOptionsItemSelected(item);
    }
}
