package com.example.student.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "marksheet")
public class Marksheet {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "rollno")
    private String markrollno;

    @ColumnInfo(name = "sem_num")
    private String marksheet_sem_num;

    @ColumnInfo(name = "subject1")
    private String marksheet_subject1;

    @ColumnInfo(name = "subject2")
    private String marksheet_subject2;

    @ColumnInfo(name = "subject3")
    private String marksheet_subject3;

    @ColumnInfo(name = "subject4")
    private String marksheet_subject4;

    @ColumnInfo(name = "subject5")
    private String marksheet_subject5;

    @ColumnInfo(name = "mark1")
    private String marksheet_mark1;

    @ColumnInfo(name = "mark2")
    private String marksheet_mark2;

    @ColumnInfo(name = "mark3")
    private String  marksheet_mark3;

    @ColumnInfo(name = "mark4")
    private String marksheet_mark4;

    @ColumnInfo(name = "mark5")
    private String marksheet_mark5;

    @ColumnInfo(name = "cgpa")
    private String marksheet_cgpa;

    public Marksheet(String markrollno, String marksheet_sem_num, String marksheet_subject1, String marksheet_subject2, String marksheet_subject3,
                     String marksheet_subject4, String marksheet_subject5, String marksheet_mark1, String marksheet_mark2, String marksheet_mark3, String marksheet_mark4, String marksheet_mark5, String marksheet_cgpa) {

        this.markrollno = markrollno;
        this.marksheet_sem_num = marksheet_sem_num;
        this.marksheet_subject1 = marksheet_subject1;
        this.marksheet_subject2 = marksheet_subject2;
        this.marksheet_subject3 = marksheet_subject3;
        this.marksheet_subject4 = marksheet_subject4;
        this.marksheet_subject5 = marksheet_subject5;
        this.marksheet_mark1 = marksheet_mark1;
        this.marksheet_mark2 = marksheet_mark2;
        this.marksheet_mark3 = marksheet_mark3;
        this.marksheet_mark4 = marksheet_mark4;
        this.marksheet_mark5 = marksheet_mark5;
        this.marksheet_cgpa = marksheet_cgpa;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarkrollno() {
        return markrollno;
    }

    public void setMarkrollno(String markrollno) {
        this.markrollno = markrollno;
    }

    public String getMarksheet_sem_num() {
        return marksheet_sem_num;
    }

    public void setMarksheet_sem_num(String marksheet_sem_num) {
        this.marksheet_sem_num = marksheet_sem_num;
    }

    public String getMarksheet_subject1() {
        return marksheet_subject1;
    }

    public void setMarksheet_subject1(String marksheet_subject1) {
        this.marksheet_subject1 = marksheet_subject1;
    }

    public String getMarksheet_subject2() {
        return marksheet_subject2;
    }

    public void setMarksheet_subject2(String marksheet_subject2) {
        this.marksheet_subject2 = marksheet_subject2;
    }

    public String getMarksheet_subject3() {
        return marksheet_subject3;
    }

    public void setMarksheet_subject3(String marksheet_subject3) {
        this.marksheet_subject3 = marksheet_subject3;
    }

    public String getMarksheet_subject4() {
        return marksheet_subject4;
    }

    public void setMarksheet_subject4(String marksheet_subject4) {
        this.marksheet_subject4 = marksheet_subject4;
    }

    public String getMarksheet_subject5() {
        return marksheet_subject5;
    }

    public void setMarksheet_subject5(String marksheet_subject5) {
        this.marksheet_subject5 = marksheet_subject5;
    }

    public String getMarksheet_mark1() {
        return marksheet_mark1;
    }

    public void setMarksheet_mark1(String marksheet_mark1) {
        this.marksheet_mark1 = marksheet_mark1;
    }

    public String getMarksheet_mark2() {
        return marksheet_mark2;
    }

    public void setMarksheet_mark2(String marksheet_mark2) {
        this.marksheet_mark2 = marksheet_mark2;
    }

    public String getMarksheet_mark3() {
        return marksheet_mark3;
    }

    public void setMarksheet_mark3(String marksheet_mark3) {
        this.marksheet_mark3 = marksheet_mark3;
    }

    public String getMarksheet_mark4() {
        return marksheet_mark4;
    }

    public void setMarksheet_mark4(String marksheet_mark4) {
        this.marksheet_mark4 = marksheet_mark4;
    }

    public String getMarksheet_mark5() {
        return marksheet_mark5;
    }

    public void setMarksheet_mark5(String marksheet_mark5) {
        this.marksheet_mark5 = marksheet_mark5;
    }

    public String getMarksheet_cgpa() {
        return marksheet_cgpa;
    }

    public void setMarksheet_cgpa(String marksheet_cgpa) {
        this.marksheet_cgpa = marksheet_cgpa;
    }
}
