package com.example.student.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.student.model.Marksheet;

@Database(entities = Marksheet.class,version = 1)
public abstract class MarksheetDB extends RoomDatabase {

    public abstract  MarksheetDao marksheetDao();
    public static final String DATABASE_NAME="marsheetDb";
    public  static  MarksheetDB insttance;

    public static MarksheetDB getInstance(Context context)
    {
        if(insttance==null)
        {
            insttance= Room.databaseBuilder(context,MarksheetDB.class,DATABASE_NAME).allowMainThreadQueries().build();
        }
        return insttance;
    }

}
