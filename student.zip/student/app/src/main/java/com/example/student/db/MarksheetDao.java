package com.example.student.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.student.model.Marksheet;

import java.util.List;

@Dao
public interface MarksheetDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertMarksheet(Marksheet marksheet);

    @Delete
    void deleteMarksheet(Marksheet marksheet);

    @Update
    void updateMarksheet(Marksheet marksheet);

    @Query("SELECT * FROM marksheet WHERE rollno = :rollno")
    List<Marksheet> getMarksheets(String rollno);

    @Query("SELECT * FROM marksheet WHERE id = :marksheetId")
    Marksheet getMarksheetById(int marksheetId);

    @Query("DELETE FROM marksheet  WHERE id = :marksheetId")
    void deleteMarksheetById(int marksheetId);
}
