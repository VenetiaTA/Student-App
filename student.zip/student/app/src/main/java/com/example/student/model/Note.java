package com.example.student.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "notes")
public class Note {

    @PrimaryKey(autoGenerate = true)
    private  int id;

    @ColumnInfo(name="rollno")
    private String noterollno;

    @ColumnInfo(name = "text")
    private String notetext;

    @ColumnInfo(name = "date")
    private  long notedate;

    public Note(String noterollno, String notetext, long notedate) {
        this.noterollno = noterollno;
        this.notetext = notetext;
        this.notedate = notedate;
    }

    public String getNotetext() {
        return notetext;
    }

    public void setNotetext(String notetext) {
        this.notetext = notetext;
    }

    public long getNotedate() {
        return notedate;
    }

    public void setNotedate(long notedate) {
        this.notedate = notedate;
    }

    public String getNoterollno() {
        return noterollno;
    }

    public void setNoterollno(String noterollno) {
        this.noterollno = noterollno;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
