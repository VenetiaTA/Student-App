package com.example.student;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public class dashboard1 extends AppCompatActivity {
    String dashboard_rollno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard1);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Bundle bundle= getIntent().getExtras();
        dashboard_rollno=bundle.getString("rollno");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu_dashboard,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId())
        {
            case R.id.menu_notes:
            {
                Intent notesintent=new Intent(this,notesactivity.class);
                notesintent.putExtra("rollno",dashboard_rollno);
                startActivity(notesintent);
                break;
            }
            case R.id.menu_marksheet:
            {
               Intent marksheetintent=new Intent(this,marksheet.class);
               marksheetintent.putExtra("rollno",dashboard_rollno);
               startActivity(marksheetintent);
               break;
            }
            case R.id.menu_logout:
                finish();
        }
        return super.onOptionsItemSelected(item);
    }

}
