package com.example.student;

import android.content.Intent;
import android.os.Bundle;

import com.example.student.adapters.MarksheetAdapter;
import com.example.student.adapters.NotesAdapter;
import com.example.student.db.MarksheetDB;
import com.example.student.db.MarksheetDao;
import com.example.student.model.Marksheet;
import com.example.student.model.Note;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class marksheet extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ArrayList<Marksheet> marksheets;
    private MarksheetAdapter marksheetAdapter;
    private MarksheetDao marksheetDao;
    String marsheet_rollno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marksheet);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerView=findViewById(R.id.marksheet_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onAddNewMarksheet();
            }
        });

        marksheetDao= MarksheetDB.getInstance(this).marksheetDao();
        Bundle bundle=getIntent().getExtras();
        marsheet_rollno=bundle.getString("rollno");
    }

    private void onAddNewMarksheet() {
        Intent marksheetedite=new Intent(this,marksheet_editie.class);
        marksheetedite.putExtra("rollno",marsheet_rollno);
        startActivity(marksheetedite);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadMarksheet();
    }

    private void loadMarksheet() {
        this.marksheets=new ArrayList<>();
        List<Marksheet> list =marksheetDao.getMarksheets(marsheet_rollno);
        this.marksheets.addAll(list);
        this.marksheetAdapter=new MarksheetAdapter(this,this.marksheets);
        this.recyclerView.setAdapter(marksheetAdapter);
        //marksheetAdapter.notifyDataSetChanged();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.homepage_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.menu_homepage:
            {
                finish();
                break;
            }
        }
        return super.onOptionsItemSelected(item);
    }
}
